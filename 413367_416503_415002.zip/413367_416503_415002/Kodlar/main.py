from mpi4py import MPI
import numpy as np
import time

def read_matrix(filename):
    with open(filename, 'r') as f:
        line = f.readline().strip()
        if not line:
            return 0, np.array([])
        N = int(line)
        matrix = np.loadtxt(f).reshape(N, N)
    return N, matrix

comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()

N = None
A = None
B = None

if rank == 0:
    N, A = read_matrix('a.txt')
    _, B = read_matrix('b.txt')
    # Bellek yerlesiminin ardisik oldugundan emin olalim
    A = np.ascontiguousarray(A, dtype='float64')
    B = np.ascontiguousarray(B, dtype='float64')

# N bilgisini yay
N = comm.bcast(N, root=0)
rows_per_proc = N // size

# Her islemci icin yer ayir
local_A = np.empty((rows_per_proc, N), dtype='float64')
if rank != 0:
    B = np.empty((N, N), dtype='float64')

# Verileri dagit
comm.Bcast(B, root=0)
comm.Scatter(A, local_A, root=0)

# Sonuç matrisinin bu işlemciye düşen kısmını sıfırlarla hazırla
local_C = np.zeros((rows_per_proc, N), dtype='float64')

start_time = time.time()

# --- Manuel For Döngüsü ile Matris Çarpımı (C = A * B) ---
for i in range(rows_per_proc):
    for j in range(N):
        # local_C[i, j] zaten 0 olarak ilklendirildi
        for k in range(N):
            local_C[i, j] += local_A[i, k] * B[k, j]
# --------------------------------------------------------

end_time = time.time()

# Sonuclari topla
C = None
if rank == 0:
    C = np.empty((N, N), dtype='float64')

comm.Gather(local_C, C, root=0)

if rank == 0:
    print(f"Python (mpi4py - Manuel Döngü) Süre: {end_time - start_time:.4f} saniye")

# Çalıştırma komutu:
# mpirun -np 4 python3 odev1.py