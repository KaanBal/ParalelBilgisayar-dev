#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

void read_matrix(const char* filename, double** matrix, int* N) {
    FILE* file = fopen(filename, "r");
    if (!file) { printf("Dosya acilamadi: %s\n", filename); MPI_Abort(MPI_COMM_WORLD, 1); }
    fscanf(file, "%d", N);
    *matrix = (double*)malloc((*N) * (*N) * sizeof(double));
    for (int i = 0; i < (*N) * (*N); i++) {
        fscanf(file, "%lf", &(*matrix)[i]);
    }
    fclose(file);
}

int main(int argc, char** argv) {
    int rank, size, N;
    double *A = NULL, *B = NULL, *C = NULL;
    double *local_A, *local_C;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (rank == 0) {
        read_matrix("a.txt", &A, &N);
        read_matrix("b.txt", &B, &N);
        C = (double*)malloc(N * N * sizeof(double));
    }

    // N bilgisini herkese gonder
    MPI_Bcast(&N, 1, MPI_INT, 0, MPI_COMM_WORLD);

    int rows_per_proc = N / size;
    local_A = (double*)malloc(rows_per_proc * N * sizeof(double));
    local_C = (double*)malloc(rows_per_proc * N * sizeof(double));
    if (rank != 0) B = (double*)malloc(N * N * sizeof(double));

    // B matrisini ve A'nin ilgili satirlarini dagit
    MPI_Bcast(B, N * N, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Scatter(A, rows_per_proc * N, MPI_DOUBLE, local_A, rows_per_proc * N, MPI_DOUBLE, 0, MPI_COMM_WORLD);

    double start_time = MPI_Wtime();

    // Matris Carpimi (C = A * B)
    for (int i = 0; i < rows_per_proc; i++) {
        for (int j = 0; j < N; j++) {
            local_C[i * N + j] = 0;
            for (int k = 0; k < N; k++) {
                local_C[i * N + j] += local_A[i * N + k] * B[k * N + j];
            }
        }
    }

    double end_time = MPI_Wtime();

    // Sonuclari Master'da topla
    MPI_Gather(local_C, rows_per_proc * N, MPI_DOUBLE, C, rows_per_proc * N, MPI_DOUBLE, 0, MPI_COMM_WORLD);

    if (rank == 0) {
        printf("C (OpenMPI) Sure: %f saniye\n", end_time - start_time);
        free(A); free(B); free(C);
    }
    free(local_A); free(local_C); if(rank != 0) free(B);

    MPI_Finalize();
    return 0;
}

//.    mpicc odev1.c -o odev1
//.    mpirun -np 4 ./odev1